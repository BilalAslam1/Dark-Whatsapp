# Dark-Whatsapp Chrome
A dark theme for whatsapp web.

## Things to be done
* Create popup menu
* Toggle button to turn on/off in popup menu
* Toggle between lightgray and dark theme 
